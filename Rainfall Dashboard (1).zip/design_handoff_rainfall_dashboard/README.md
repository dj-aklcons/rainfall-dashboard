# Handoff: Auckland Rainfall Dashboard

## Overview

A council-style monitoring dashboard for hourly rainfall telemetry from four Auckland rain-gauge stations (Auckland Central, Waitakere, Takapuna, Manukau). It surfaces 24h / 7d / 30d totals, hour-of-day heatmaps, threshold-based alerts (with an optional AI briefing), a regional map view, and a per-station drill-in with line + bar charts and metadata. The product target is conservation/operations staff who need to spot heavy-rain events and surface-runoff risk fast.

## About the Design Files

The files in this bundle are **design references created as a working HTML/React prototype** — they demonstrate intended look, layout, copy, and interactive behavior. They are **not production code to copy directly**.

The implementation task is to **recreate these designs in the target codebase's environment** (React, Vue, SvelteKit, SwiftUI, native, etc.), using its established component library, state-management patterns, charting library, and design tokens. If no environment exists yet, pick the framework most appropriate for the project (a typed React + Vite + a charting lib like Recharts/visx, or D3 inside framework components, would be a sensible default) and implement there.

The included `charts.jsx` is a custom hand-rolled SVG chart implementation — **do not port it verbatim**; use the charting library that ships with the target codebase and match the visual style described below.

## Fidelity

**High-fidelity (hifi).** The prototype is pixel-targeted with final colors, typography, spacing, radii, motion, and copy. Reproduce these values exactly. The Tweaks panel and any obvious mock-data generators (`data.js`, `region-shapes.js`) are scaffolding for the prototype, not part of the product surface.

---

## Design Tokens

All values are from the prototype's `styles.css` and are the source of truth.

### Color palette (raw)

| Token | Hex | Use |
|---|---|---|
| `--c-dark1` | `#000000` | Pure black (rarely used) |
| `--c-light1` | `#ffffff` | Surface (light mode) |
| `--c-dark2` | `#4e2a41` | Plum (dark mode surface base, accent option) |
| `--c-light2` | `#e8e8e8` | Border (light mode) |
| `--c-accent1` | `#155f82` | Deep teal — primary accent (light default) |
| `--c-accent2` | `#e97132` | Orange — `--danger` |
| `--c-accent3` | `#196b24` | Green — `--ok` |
| `--c-accent4` | `#0f9ed5` | Sky — primary accent (dark default) |
| `--c-accent5` | `#a02b93` | Magenta |
| `--c-accent6` | `#4ea72e` | Lime — `--ok` (dark) |
| `--c-link` | `#467886` | Link color |
| `--c-link-v` | `#96607d` | Visited link color |

### Semantic tokens — Light

```
--bg:             #fafaf9
--surface:        #ffffff
--surface-2:      #f3f1ef
--border:         #e8e8e8
--border-strong:  #d4d0cc
--text:           #1a1718
--text-muted:     #6b5e64
--text-soft:      #9a8e94
--accent:         #155f82      (deep teal)
--accent-soft:    #155f821a    (10% alpha)
--accent-strong:  #0d4159
--danger:         #e97132
--warn:           #c2691f
--ok:             #196b24
```

### Semantic tokens — Dark

```
--bg:             #1a1014
--surface:        #241620
--surface-2:      #2c1c27
--border:         #3a2632
--border-strong:  #523544
--text:           #f4ebef
--text-muted:     #b4a0aa
--text-soft:      #806775
--accent:         #0f9ed5      (sky)
--accent-soft:    #0f9ed51f
--accent-strong:  #4cb8e0
--danger:         #f08b56
--warn:           #f0a956
--ok:             #4ea72e
```

### Accent presets (user-selectable)

Stored as the light-mode hex; dark mode swaps to the brighter sibling.

| Name | Light | Dark |
|---|---|---|
| Teal (default) | `#155f82` | `#0f9ed5` |
| Sky | `#0f9ed5` | `#4cb8e0` |
| Green | `#196b24` | `#4ea72e` |
| Plum | `#4e2a41` | `#96607d` |
| Orange | `#e97132` | `#f0a956` |
| Magenta | `#a02b93` | `#c45cb6` |

### Spacing & radii

```
--radius:    14px    (cards, alerts)
--radius-sm: 8px     (stat grid, small buttons)
--pad:       20px    (card interior)   /* compact density: 14px */
--gap:       16px    (grid gap)        /* compact density: 12px */
```

Button paddings in the controls bar are `6–7px × 11–12px`. Card head/foot use a 12px gap.

### Shadows

```
--shadow-sm:  0 1px 2px rgba(15,23,42,0.04), 0 1px 0 rgba(15,23,42,0.02)
--shadow-md:  0 6px 24px -12px rgba(15,23,42,0.18), 0 2px 6px -2px rgba(15,23,42,0.06)
/* dark */
--shadow-sm:  0 1px 0 rgba(255,255,255,0.02)
--shadow-md:  0 12px 32px -16px rgba(0,0,0,0.6)
```

### Typography

- **Sans:** `"Geist", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`
  - Font features: `"ss01", "cv11"`
  - Antialiasing on, `letter-spacing: -0.005em` body default
- **Mono:** `"Geist Mono", ui-monospace, "SF Mono", Menlo, Consolas, monospace`
  - Used for ALL numeric readouts, status pills, axis labels, station codes, metadata rows, control labels, badges

Type scale:

| Role | Family | Size | Weight | Letter-spacing |
|---|---|---|---|---|
| Brand strong | Sans | 15px | 600 | -0.01em |
| Brand sub (eyebrow) | Mono | 11px | 400 | 0.04em, uppercase |
| Page H2 (drill-in name) | Sans | 22px | 600 | -0.02em |
| Heatmap title | Sans | 18px | 600 | — |
| Card H3 (station name) | Sans | 14px | 600 | -0.01em |
| Card subtitle (site) | Mono | 11.5px | 400 | — |
| Section label (eyebrow) | Mono | 12px | 500 | 0.08em, uppercase |
| Body | Sans | 13–13.5px | 400 | -0.005em |
| Metric — large | Mono | 32px | 500 | -0.02em, tabular-nums |
| Metric — medium | Mono | 20–22px | 500 | -0.01 to -0.02em, tabular-nums |
| Stat label | Mono | 10.5px | 400 | 0.06em, uppercase |
| Axis/tick labels | Mono | 9–10px | 400 | — |
| Badge | Mono | 10.5px | 400 | 0.04em, uppercase |
| Tooltip | Mono | 11.5px | 400 | — |

Numeric readouts MUST use `font-variant-numeric: tabular-nums` so digits don't jiggle as values update.

---

## App Shell

### Layout

- Root: `max-width: 1480px`, centered, vertical padding `28px top` / `80px bottom`, horizontal padding `clamp(16px, 4vw, 40px)`.
- Vertical structure: Header → ControlsBar (hidden in drill-in) → active view → Tweaks panel (floating, optional).

### Header (`.topbar`)

Flex row, space-between, gap `16px`, bottom border, `padding-bottom: 22px`, `margin-bottom: 22px`.

- **Left — Brand**
  - `36×36` accent-filled rounded-square mark (`border-radius: 10px`) containing a 22px white water-drop icon.
  - Two-line text block: strong product name "Auckland Rainfall" + uppercase mono eyebrow `LIBRARIES · CONSERVATION MONITORING`.
- **Right — status & actions**
  - Status pill: rounded-full `border-radius: 999px`, mono 12px, leading status dot (`7×7`, green w/ 25% halo, pulses amber when refreshing). Text: "Updated 12m ago" / "Refreshing…".
  - Icon buttons: `36×36`, `border-radius: 10px`, 1px border. Refresh (spins on click) and theme toggle (sun/moon).

### Tabs (in ControlsBar left)

Pill-segmented control, gray track (`--surface-2`), 4px inner padding, 1px border, `border-radius: 10px`. Each tab `7px × 12px`, 13px medium. Active tab has white surface + `--shadow-sm`. Icons 14px, gap 7px. Tabs: **Dashboard**, **Map**, **Heatmap**, **Alerts**.

### Controls bar (`.controls`)

Flex row, wraps, gap `16px`, `margin-bottom: 20px`. Contains tabs on the left and contextual filters on the right.

- **Locations** (dashboard only) — pill toggles per station (`border-radius: 999px`, 1px border, 12px). Pressed state: solid `--text` background, `--surface` text.
- **Range** — segmented `24h / 7d / 30d`. Active button has `--accent` fill + white text.
- **Unit** — segmented `mm/h / total mm`.
- Each labeled by an uppercase mono "eyebrow" (`.control-label`, 11px, `letter-spacing: 0.06em`, color `--text-soft`).

Map view hides the locations + range + unit cluster entirely (`hideRangeControls`).

---

## Views

### 1. Dashboard view

Grid of four `StationCard`s.

- Grid: 1 column on `<640px`, 2 columns up to `1100px`, **4 columns** at `≥1100px`. Gap `var(--gap)`.

#### StationCard

- Card chrome: `--surface` bg, 1px `--border`, `--radius` (14px), `--pad` (20px), `--shadow-sm`. Vertical flex, gap 12px. Clickable: pointer cursor, `translateY(-1px)` + `--shadow-md` + `--border-strong` on hover, `160ms ease`.
- Sections:
  1. **Head** — flex row, items-start, space-between:
     - Left: station name (sans 14/600/-0.01em) + site code (mono 11.5px, `--text-muted`).
     - Right: status badge pill (mono 10.5px uppercase, 0.04em tracking, 3px×7px padding, 999px radius).
       - `Heavy` (severity high): `color-mix(in oklab, var(--danger) 12%, transparent)` bg, `--danger` text.
       - `Wet` (med): `--accent-soft` bg, `--accent` text.
       - `Active` (any rain): same wet styling.
       - `Quiet` (no rain): `--surface-2` bg, `--text-muted` text, 1px border.
  2. **Metric row** — flex, baseline, space-between:
     - Left: big mono number `mm total` (32px/500/-0.02em, tabular-nums) + small mono unit "mm total · {range}" (12px, muted).
     - Right: two-line mono 11px sub-text — `peak <strong>X mm/h</strong>` / `N of Hh wet`.
  3. **Bar chart** — see Charts § BarChart. Height `110px` for 24h, `90px` for 7d/30d.
  4. **Chart foot** — flex row space-between, mono 10.5px `--text-soft`, contents `ts_id 648719` left / `tap to drill in →` right.

#### Severity rules

```
severityFor(total, range):
  norm = total                  if range === "24h"
       = total / 3              if range === "7d"
       = total / 8              if range === "30d"
  >= 50  -> "high"
  >= 25  -> "med"
  >= 10  -> "low"
  else null
```

### 2. Map view

A 2×2 grid of region tiles (one per station) with abstract SVG region shapes. See `region-shapes.js` and `map.jsx` for the geometry and component.

- Card header: title "Auckland regions" + total rainfall metric on the right.
- Tile (`.region-tile`):
  - `min-height: 280px`, vertical flex, rounded `var(--radius)`, 1px border, overflow hidden.
  - Top: region SVG centered in a soft radial-gradient background, 16px padding, min-height 200px, `--surface` bg with a subtle top-left dark wash.
  - Bottom (`.region-tile-meta`): 12px×16px padded footer with a top border, `--surface` bg; left = station name (14/600) + site (mono 11/muted, truncates with ellipsis); right = mono total `22px/500/-0.02em` + mono 10.5px "{range} total" caption.
  - Hover: same translateY/shadow treatment as `.card.clickable`.
- Region shape colors: fill with `--accent-soft`, stroke with `--accent` at the appropriate opacity (see `map.jsx`).

### 3. Heatmap view

Card containing a 24-column grid showing hour-of-day mean intensity per station.

- Header row: left = title "Hour-of-day intensity" + mono caption "Average mm/h by hour, last N day(s)"; right = legend (label "0" — 140px gradient bar — label "peak"). Gradient: `linear-gradient(to right, --surface-2, accent@30%, accent@70%, accent)`.
- Body grid: `grid-template-columns: 110px repeat(24, 1fr)`, `gap: 2px`, `min-width: 720px`, wrapped in `overflow-x: auto`.
- First row is the hour axis: each cell `.hm-axis` is mono 10px, `--text-soft`, centered, padded 4px.
- Subsequent rows = one per station; first cell `.hm-label` = station name (sans 12/500); 24 cells `.hm-cell`:
  - `aspect-ratio: 1.4 / 1`, `border-radius: 3px`.
  - Empty: `--surface-2`.
  - Filled: `color-mix(in oklab, var(--accent) {20 + intensity*80}%, var(--surface-2))`.
  - Hover: 2px `--accent` outline w/ 1px offset, z-index 2.
  - Native tooltip `title="HH:00 — X mm/h avg"`.

### 4. Alerts view

Vertical stack of:

1. **AI summary card** (optional, controlled by `showAI` tweak):
   - `linear-gradient(135deg, var(--accent-soft), transparent)` bg, 1px border, `--radius` corners, 16px padding, flex row.
   - 28×28 accent-filled rounded-square icon with white 14px spark glyph.
   - Body: mono uppercase 10.5px label "Conservation briefing · AI" in `--accent`; 13.5px text body. While loading, shows "Generating briefing…". A "Regenerate" filter-pill button below when not loading.
   - On mount and when toggled on, fetches a short 60-word briefing via the host's LLM endpoint with the 24h station facts.
2. **Threshold control card** — numeric input (70px, mono, 1px border, `--radius: 6px` corners) for the 24h alert threshold in mm, with the eyebrow "24H ALERT THRESHOLD" and a muted caption referencing MetService's 50mm/24h heavy-rain warning.
3. **Alert cards** (`.alert-card`):
   - 3px left border (severity-tinted: `--danger` high / `--warn` med / `--ok` low), 1px borders on the other sides, `--radius` corners, `--pad` interior, flex row gap 14px.
   - 32×32 rounded-square icon tile, severity-tinted background (`color-mix(--danger 14%, transparent)` etc.), 16px icon centered.
   - Body: title (13.5/600/-0.01em), mono meta line "{day · time} · severity {sev}", body 13px/muted with 1.5 line-height.

Alert generation: any station with 24h total ≥ threshold yields a "Total" alert (high if ≥ 2× threshold, else med); peak ≥ 8 mm/h yields a "Peak" alert (high if ≥ 15). If no station qualifies, render a single calm "No active warnings" card with severity low.

### 5. Drill-in view (per-station)

Triggered by clicking a StationCard or a map tile.

- Two-column grid at `≥980px`: main left (2fr), side right (1fr); single column below. Gap `var(--gap)`.
- Above the columns: a "← All stations" back button (12.5px muted, hover surface).
- **Main column**
  1. Card (gap 16px):
     - Top row, flex space-between:
       - Left: station name (22/600/-0.02em), mono 12.5 sub `site · lat°, lng° · elevation m`.
       - Right: column-aligned big metric `mm · range` (32px mono) + mono 11px "vs prior 24h ±X mm" (accent for positive trend, muted otherwise).
     - LineChart, height 300. See Charts § LineChart.
  2. Card "HOURLY INTENSITY" (section title pattern) → BarChart height 150.
- **Side column**
  - **Stat grid**: 2×2 grid with 1px gutters (bg `--border` showing through), `border-radius: 8px`, overflow hidden. Each `.stat` has 14px padding, vertical flex gap 4px: tiny uppercase mono label + mono `20px/500/-0.01em` value with a smaller muted unit.
    - "Peak intensity" — X mm/h
    - "Wet hours" — N / total
    - "Longest dry" — Nh
    - "Peak at" — 14px formatted "Wed 13 Nov · 14:00"
  - **Station metadata** card: section-title eyebrow + key/value `.meta-list` (mono 12.5px, muted keys, `--text` values @ 500). Keys: Site code, ts_id, Parameter (`Rainfall.HOURTOT`), Elevation, Timezone (`Pacific/Auckland`), Data source (`hydrotel · KiWIS`).
  - **Quality flags** card: same `.meta-list` pattern. "Good (QC 1)" / "Suspect (QC 200)".

---

## Charts

The prototype draws all charts as inline SVG inside React components (`charts.jsx`). **Don't port the SVG code directly**; reimplement using the target codebase's chart library while matching the visual recipe below.

### Common rules

- Use the active `--accent` for fills/strokes; bars get `opacity: 0.95`, drop to `0.55` when another bar is hovered (`120ms ease`); hovered bar `opacity: 1`. Zero-value bars: `opacity: 0.08`.
- Bar `border-radius` is `min(1.5, barWidth/2)` — i.e. essentially sharp pixel corners at small widths.
- Gridlines: 1px `--border`. Top + middle dashed `2 3`; baseline solid.
- Y-axis label is a small mono 9px `"{max} mm"` annotation at top-left.
- Axis text: mono 9–10px, `--text-soft`, centered.
- Hover indicator: 1px vertical line, `stroke: var(--text); stroke-opacity: 0.25`.
- Tooltip (`.chart-tooltip`):
  - Absolute, `transform: translate(-50%, -110%)`, dark `--text` bg, `--surface` text, mono 11.5px, 7×9 padding, `border-radius: 7px`, `--shadow-md`, `z-index: 5`.
  - Two lines: `**{value} mm**/h` or `mm total`, plus a faded mono time line (60% opacity).
  - The bold value adopts `--accent-strong` in light mode, `--accent` in dark.

### BarChart (hourly, used in cards & drill-in)

- **Data:** hourly rainfall series. `mode="hourly"` plots raw values; `mode="cumulative"` plots a running sum.
- **Sizing:** SVG viewBox `0 0 320 H` with `preserveAspectRatio="none"` so it stretches horizontally. Padding: 4px X, 12px top (8px compact), 18px bottom for axis (14px compact).
- **Y max:** rounded up — `<1→1, <2→2, <5→ceil, <10→ceil/2*2, <50→ceil/5*5, else ceil/10*10`.
- **X-axis labels (IMPORTANT — adaptive to range):**
  - Compute total span in hours from data.
  - If `span ≤ 36h`: show labels every 6h aligned to clock, formatted `HH:00`.
  - Else if `span ≤ 240h` (~10d): show day labels at hour 0 of each day, formatted as short weekday (`Mon`).
  - Else (longer, e.g. 30d): show date labels at hour 0 of each day, formatted as `D MMM` (e.g. `8 May`).
  - Then thin evenly: if `candidates.length > maxLabels` (4 in cards, 5 in drill-in), filter by stride `ceil(length / maxLabels)`. Goal: labels never crowd or overlap.
- **Hover:** mouse/touch position → derive bar index from x-coordinate, draw hover indicator + tooltip.

### LineChart (drill-in)

- **Sizing:** SVG viewBox `0 0 800 H`, padding `36L / 14R / 16T / 28B`. Height defaults 280, used at 300 in drill-in.
- **Y ticks:** 5 ticks at 0/25/50/75/100% of max. Labels right-aligned, mono 10px. Top tick dashed; baseline solid.
- **Line:** 1.8px stroke, accent color, `linejoin/linecap: round`.
- **Area fill:** same accent at `opacity: 0.1` below the line.
- **X ticks:** approximately `min(8, max(4, n/8))` evenly-spaced timestamps using `HH:MM` formatting.
- **Hover:** 4px circle marker at the data point — `fill: var(--surface)`, 2px accent stroke. Tooltip positioned at `(px, py)`.

### Heatmap row

Already covered above under "Heatmap view".

---

## Interactions & Behavior

- **Tab switching** clears any open station drill-in and renders the new view; Tabs are also rendered inside the controls bar.
- **Range / unit changes** are global state and affect every view that consumes them.
- **Location filter pills** toggle which stations the Dashboard grid renders. Drill-in ignores filtering.
- **Refresh button**:
  - Sets `refreshing = true`, updates the status pill to "Refreshing…" with a pulsing amber dot, and spins the icon (`animation: spin .8s linear infinite`).
  - After 900ms, bumps a seed (regenerates mock data in the prototype — in production, refetch from the telemetry endpoint), updates `lastUpdated`, returns refreshing to false.
- **Theme toggle**: flips `data-theme` between `light` and `dark` on `<html>` (sets the entire token set). Persist via the user's preference store.
- **Density**: `data-density="compact"` shortens pad/gap/radius. Persist as user preference.
- **Accent**: setting the light hex automatically picks the corresponding dark hex from the preset table when theme is dark. Sets `--accent` and `--accent-soft` (accent + `1f` alpha) on the root.
- **Station card → Drill-in**: click or Enter key; the back button returns to the previous view.
- **Hover/focus states**:
  - Cards: `translateY(-1px)` + `--shadow-md` + `--border-strong`, `160ms ease`.
  - Bars: opacity dim non-hovered to 0.55.
  - Heatmap cells: 2px outline.
  - Pills/segments: muted → text on hover.
- **AI briefing**: on Alerts view mount (if enabled), call the host's LLM completion endpoint with a hydrology-analyst prompt + JSON facts for 24h per station, asking for ~60 words. Show "Generating briefing…" while loading. Display the result with a "Regenerate" button.

### Motion timings

- Hover transitions: `120–160ms ease`.
- Refresh icon spin: `0.8s linear infinite`.
- Status dot pulse: `1.2s ease-in-out infinite`.
- Bar opacity transitions: `120ms`.

---

## State

Top-level state owned by `App`:

```
view:        "dashboard" | "map" | "heatmap" | "alerts"
openedId:    string | null            // drill-in target
range:       "24h" | "7d" | "30d"
unit:        "rate" | "total"         // rate = mm/h, total = cumulative
filter:      string[]                 // selected station ids
seed:        number                   // refresh trigger / mock data seed
refreshing:  boolean
lastUpdated: Date

// User preferences (persist):
theme:       "light" | "dark"
accent:      hex (light-mode hex from preset table)
density:     "comfy" | "compact"
showAI:      boolean
```

Derived: `stations`, `accentHex` (theme-resolved), `openedStation`.

In Alerts view, `threshold` (mm) is local component state with default 25; `aiText` / `aiLoading` for the briefing.

---

## Data Shape

Each station object:

```
{
  id: "central" | "waitakere" | "takapuna" | "manukau",
  name: string,        // display name, e.g. "Auckland Central"
  site: string,        // e.g. "Albert Park"
  ts_id: string,       // KiWIS time-series id, e.g. "648719"
  lat: number,
  lng: number,
  elevation: number,   // metres
  series: Array<{
    timestamp: ISO string,
    value: number,     // hourly mm
    quality: 1 | 200,  // 1 = good, 200 = suspect
  }>,
}
```

The four production stations are documented in `data.js` with their real `ts_id`s and coordinates. In production, fetch from the Auckland Council hydrotel KiWIS endpoint; parameter is `Rainfall.HOURTOT`.

---

## Assets

- **Fonts:** Geist + Geist Mono via Google Fonts. The codebase should self-host or import via its existing font pipeline. Weights used: 400, 500, 600, 700.
- **Icons:** All icons in the design are hand-drawn inline SVGs (water drop, refresh, grid, heatmap, bell, back chevron, spark/sparkle, warning triangle, map fold, sun, moon). 24×24 viewBox, `stroke-width: 2`, round caps & joins (drop is filled). In the target codebase, substitute equivalents from the existing icon library (lucide-react / phosphor / material-symbols / SF Symbols / etc.). Match the visual weight (2px stroke, round joins).
- **Region shapes:** abstract path data in `region-shapes.js` — not actual cartography, just regional silhouettes. Reuse or replace with real GeoJSON if available.
- **No raster imagery** is used.

---

## Responsive Behavior

- **Dashboard grid:** 1 col `<640px` / 2 col `≥640px` / 4 col `≥1100px`.
- **Drill-in:** 1 col `<980px` / 2 col `≥980px` (2fr + 1fr).
- **Region grid:** 1 col `<720px` / 2 col `≥720px`.
- **Below 720px:**
  - Topbar wraps.
  - Tabs scroll horizontally (`overflow-x: auto`).
  - Large metric drops from 32px → 26px.
  - Controls gap shrinks to 10px.
  - Stat grid stays 2 cols (`1fr 1fr`).

---

## Files in This Handoff

- `Rainfall Dashboard.html` — entry HTML (font preconnect, React + Babel CDN imports, script tags).
- `app.jsx` — App shell, routing/view switching, controls, StationCard, DashboardView, DrillView, HeatmapView, AlertsView, Tweaks integration.
- `charts.jsx` — BarChart, LineChart, HeatmapRow, BlockBarChart implementations (reference only — re-do in your charting library).
- `map.jsx` — Map view with region tiles.
- `region-shapes.js` — SVG path data for the four region shapes.
- `data.js` — Mock data generator with the real station metadata + `ts_id`s (replace with real telemetry fetching in production).
- `styles.css` — All design tokens, layout, component CSS. **Primary source of truth for visual values.**
- `tweaks-panel.jsx` — Prototype-only tweaks UI; do not ship.

When implementing, treat `styles.css` and this README as the spec, and the JSX as a behavioural reference.

---

## Implementation Suggestions

- **Charts:** Recharts or visx in React; ECharts also fits the visual style. For SwiftUI, Swift Charts. The custom BarChart's adaptive x-axis label logic (hourly / weekday / date based on span, then thinned evenly to ≤4–5 labels) is product-critical — many libraries default to far too many ticks at 7d/30d. Implement an explicit `tickFormatter` + tick filter.
- **Color tokens:** Stage them as CSS custom properties (or `@Environment` keys / Tailwind theme entries) so theme + accent swaps are a single property update on the root.
- **Tabular numerals:** ensure `font-variant-numeric: tabular-nums` (or equivalent SwiftUI `.monospacedDigit()`) is applied to every numeric readout.
- **Accent → CSS:** set both `--accent` and `--accent-soft` (hex + `1f` alpha) on the root when accent or theme changes.
- **AI briefing:** wire to the project's existing LLM proxy; the prompt is documented in `app.jsx → generateSummary`. Keep the ~60-word constraint and the "no bullets/headers" instruction.
- **Persistence:** theme, density, accent, showAI should persist per user (localStorage, account preferences, etc.). The Tweaks panel in the prototype is not part of the product surface.
