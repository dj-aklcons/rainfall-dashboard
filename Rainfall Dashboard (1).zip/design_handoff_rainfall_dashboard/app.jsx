/* global React, ReactDOM, RainfallData, BarChart, LineChart, HeatmapRow, fmtMM, fmtDayHour, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, TweakColor, TweakSlider, TweakSelect */
const { useState, useEffect, useMemo, useRef } = React;

// Accent presets pulled directly from the supplied palette.
// Stored value is the light-mode hex; dark-mode shifts to a brighter sibling.
const ACCENT_PRESETS = [
{ light: "#155f82", dark: "#0f9ed5", name: "Teal" }, // Accent 1 → Accent 4
{ light: "#0f9ed5", dark: "#4cb8e0", name: "Sky" }, // Accent 4
{ light: "#196b24", dark: "#4ea72e", name: "Green" }, // Accent 3 → Accent 6
{ light: "#4e2a41", dark: "#96607d", name: "Plum" }, // Dark 2 → Followed
{ light: "#e97132", dark: "#f0a956", name: "Orange" }, // Accent 2
{ light: "#a02b93", dark: "#c45cb6", name: "Magenta" } // Accent 5
];

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "#155f82",
  "density": "comfy",
  "showAI": true
} /*EDITMODE-END*/;

/* =================== Icons =================== */
const Icon = {
  drop: (p) =>
  <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <path d="M12 2.5s7 8.2 7 12.7a7 7 0 1 1-14 0C5 10.7 12 2.5 12 2.5z" />
    </svg>,

  refresh: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M21 12a9 9 0 1 1-3-6.7" />
      <path d="M21 4v5h-5" />
    </svg>,

  grid: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </svg>,

  heatmap: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M3 15h18M9 3v18M15 3v18" />
    </svg>,

  bell: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8z" />
      <path d="M10 21a2 2 0 0 0 4 0" />
    </svg>,

  back: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M15 18l-6-6 6-6" />
    </svg>,

  spark: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1" />
    </svg>,

  warn: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 9v4M12 17h.01" />
      <path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" />
    </svg>,

  map: (p) =>
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
  strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M9 3 3 6v15l6-3 6 3 6-3V3l-6 3-6-3z" />
      <path d="M9 3v15M15 6v15" />
    </svg>

};

/* =================== Helpers =================== */
function hoursForRange(range) {
  return { "24h": 24, "7d": 24 * 7, "30d": 24 * 30 }[range] || 24;
}
function stats(series) {
  const total = series.reduce((s, p) => s + p.value, 0);
  const peakP = series.reduce((m, p) => p.value > m.value ? p : m, series[0]);
  const wetHours = series.filter((p) => p.value >= 0.2).length;
  const maxIntensity = peakP.value;
  return { total, peak: peakP, wetHours, maxIntensity };
}
function severityFor(total, range) {
  // Council-style banding: heavy rain warning when 24h > 50mm; advisory > 25mm
  const norm = range === "24h" ? total : range === "7d" ? total / 3 : total / 8;
  if (norm >= 50) return "high";
  if (norm >= 25) return "med";
  if (norm >= 10) return "low";
  return null;
}

/* =================== Header =================== */
function Header({ lastUpdated, refreshing, onRefresh, theme, onThemeToggle }) {
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark" aria-hidden>
          <Icon.drop />
        </div>
        <div className="brand-text">
          <strong>Auckland Rainfall</strong>
          <span>LIBRARIES · CONSERVATION MONITORING</span>
        </div>
      </div>
      <div className="topbar-right">
        <div className="status-pill" title="Connected to hydrotel telemetry feed">
          <span className={`status-dot${refreshing ? " loading" : ""}`} />
          <span>{refreshing ? "Refreshing…" : `Updated ${fmtRel(lastUpdated)}`}</span>
        </div>
        <button className={`icon-btn${refreshing ? " spinning" : ""}`}
        onClick={onRefresh} title="Refresh data" aria-label="Refresh">
          <Icon.refresh />
        </button>
        <button className="icon-btn" onClick={onThemeToggle}
        title={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
        aria-label="Toggle theme">
          {theme === "dark" ?
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
          strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="4" />
              <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
            </svg> :

          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
          strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
            </svg>
          }
        </button>
      </div>
    </header>);

}
function fmtRel(d) {
  if (!d) return "—";
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 5) return "just now";
  if (diff < 60) return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/* =================== Tabs =================== */
function Tabs({ value, onChange }) {
  const items = [
  { id: "dashboard", label: "Dashboard", icon: Icon.grid },
  { id: "map", label: "Map", icon: Icon.map },
  { id: "heatmap", label: "Heatmap", icon: Icon.heatmap },
  { id: "alerts", label: "Alerts", icon: Icon.bell }];

  return (
    <div className="tabs" role="tablist">
      {items.map((it) => {
        const I = it.icon;
        return (
          <button
            key={it.id}
            className="tab"
            aria-selected={value === it.id}
            onClick={() => onChange(it.id)}
            role="tab">
            
            <I /> {it.label}
          </button>);

      })}
    </div>);

}

/* =================== Controls bar =================== */
function ControlsBar({ range, onRange, unit, onUnit, stations, filter, onFilter, showLocations, hideRangeControls }) {
  return (
    <div className="controls">
      <div className="control-group">
        <Tabs value={ControlsBar._tab} onChange={ControlsBar._onTab} />
      </div>
      {!hideRangeControls &&
      <div className="control-group">
          {showLocations &&
        <>
              <span className="control-label">Locations</span>
              <div className="filter-pills">
                {stations.map((s) =>
            <button
              key={s.id}
              className="filter-pill"
              aria-pressed={filter.includes(s.id)}
              onClick={() => onFilter(s.id)}>
              
                    {s.name}
                  </button>
            )}
              </div>
            </>
        }
          <span className="control-label">Range</span>
          <div className="segmented">
            {["24h", "7d", "30d"].map((r) =>
          <button key={r} aria-pressed={range === r} onClick={() => onRange(r)}>
                {r}
              </button>
          )}
          </div>
          <span className="control-label">Unit</span>
          <div className="segmented">
            <button aria-pressed={unit === "rate"} onClick={() => onUnit("rate")}>mm/h</button>
            <button aria-pressed={unit === "total"} onClick={() => onUnit("total")}>total mm</button>
          </div>
        </div>
      }
    </div>);

}

/* =================== Station Card =================== */
function StationCard({ station, range, unit, accent, chartType, onOpen }) {
  const hours = hoursForRange(range);
  const series = station.series.slice(-hours);
  const s = stats(series);
  const sev = severityFor(s.total, range);
  return (
    <article className="card clickable" onClick={() => onOpen(station.id)}
    role="button" tabIndex={0}
    onKeyDown={(e) => e.key === "Enter" ? onOpen(station.id) : null}>
      <div className="station-card-head">
        <div>
          <h3 className="station-name">{station.name}</h3>
          <div className="station-site">{station.site}</div>
        </div>
        {sev === "high" ?
        <span className="station-badge alert">Heavy</span> :
        sev === "med" ?
        <span className="station-badge wet">Wet</span> :
        s.total > 0.5 ?
        <span className="station-badge wet">Active</span> :

        <span className="station-badge">Quiet</span>
        }
      </div>
      <div className="metric-row">
        <div>
          <span className="metric-big">{fmtMM(s.total)}</span>
          <span className="metric-unit">mm total · {range}</span>
        </div>
        <div className="metric-sub">
          peak <strong>{fmtMM(s.maxIntensity)} mm/h</strong><br />
          <span>{s.wetHours} of {hours}h wet</span>
        </div>
      </div>
      <BarChart
        series={series}
        accent={accent}
        mode={unit === "total" ? "cumulative" : "hourly"}
        height={range === "24h" ? 110 : 90}
        compact={false} />
      
      <div className="chart-foot">
        <span>ts_id {station.ts_id}</span>
        <span>tap to drill in →</span>
      </div>
    </article>);

}

/* =================== Dashboard view =================== */
function DashboardView({ stations, range, unit, accent, chartType, filter, onOpen }) {
  const filtered = stations.filter((s) => filter.includes(s.id));
  return (
    <section>
      <div className="grid-4">
        {filtered.map((s) =>
        <StationCard
          key={s.id}
          station={s}
          range={range}
          unit={unit}
          accent={accent}
          chartType={chartType}
          onOpen={onOpen} />

        )}
      </div>
    </section>);

}

/* =================== Drill-in view =================== */
function DrillView({ station, range, unit, accent, onBack }) {
  const hours = hoursForRange(range);
  const series = station.series.slice(-hours);
  const s = stats(series);
  const dryStretch = useMemo(() => {
    let max = 0;let cur = 0;
    for (const p of series) {
      if (p.value < 0.05) {cur++;if (cur > max) max = cur;} else cur = 0;
    }
    return max;
  }, [series]);

  const recent24 = station.series.slice(-24);
  const prev24 = station.series.slice(-48, -24);
  const trend = recent24.reduce((a, b) => a + b.value, 0) - prev24.reduce((a, b) => a + b.value, 0);

  return (
    <section className="drill">
      <div className="drill-main">
        <button className="back-btn" onClick={onBack}>
          <Icon.back /> All stations
        </button>
        <div className="card" style={{ gap: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
            <div>
              <h2 style={{ margin: "0 0 4px", fontSize: 22, letterSpacing: "-0.02em" }}>{station.name}</h2>
              <div style={{ color: "var(--text-muted)", fontFamily: "var(--font-mono)", fontSize: 12.5 }}>
                {station.site} · {station.lat.toFixed(4)}°, {station.lng.toFixed(4)}° · {station.elevation} m
              </div>
            </div>
            <div className="metric-row" style={{ flexDirection: "column", alignItems: "flex-end", gap: 0 }}>
              <div className="metric-big">{fmtMM(s.total)}<span className="metric-unit">mm · {range}</span></div>
              <div className="metric-sub" style={{ marginTop: 6 }}>
                vs prior 24h <strong style={{ color: trend > 0 ? "var(--accent)" : "var(--text-muted)" }}>
                  {trend > 0 ? "+" : ""}{fmtMM(trend)} mm
                </strong>
              </div>
            </div>
          </div>
          <LineChart series={series} accent={accent} mode={unit === "total" ? "cumulative" : "hourly"} height={300} />
        </div>

        <div className="card">
          <h4 className="section-title">Hourly intensity</h4>
          <BarChart series={series} accent={accent} mode="hourly" height={150} />
        </div>
      </div>

      <div className="drill-side">
        <div className="stat-grid">
          <div className="stat">
            <div className="stat-label">Peak intensity</div>
            <div className="stat-value">{fmtMM(s.maxIntensity)}<span className="u">mm/h</span></div>
          </div>
          <div className="stat">
            <div className="stat-label">Wet hours</div>
            <div className="stat-value">{s.wetHours}<span className="u">/ {hours}</span></div>
          </div>
          <div className="stat">
            <div className="stat-label">Longest dry</div>
            <div className="stat-value">{dryStretch}<span className="u">h</span></div>
          </div>
          <div className="stat">
            <div className="stat-label">Peak at</div>
            <div className="stat-value" style={{ fontSize: 14 }}>{s.peak ? fmtDayHour(s.peak.timestamp) : "—"}</div>
          </div>
        </div>

        <div className="card">
          <h4 className="section-title">Station metadata</h4>
          <div className="meta-list">
            <div className="row"><span>Site code</span><strong>{station.id.toUpperCase()}</strong></div>
            <div className="row"><span>ts_id</span><strong>{station.ts_id}</strong></div>
            <div className="row"><span>Parameter</span><strong>Rainfall.HOURTOT</strong></div>
            <div className="row"><span>Elevation</span><strong>{station.elevation} m</strong></div>
            <div className="row"><span>Timezone</span><strong>Pacific/Auckland</strong></div>
            <div className="row"><span>Data source</span><strong>hydrotel · KiWIS</strong></div>
          </div>
        </div>

        <div className="card">
          <h4 className="section-title">Quality flags</h4>
          <div className="meta-list">
            {(() => {
              const flagged = series.filter((p) => p.quality !== 1).length;
              return (
                <>
                  <div className="row"><span>Good (QC 1)</span><strong>{series.length - flagged}</strong></div>
                  <div className="row"><span>Suspect (QC 200)</span><strong>{flagged}</strong></div>
                </>);

            })()}
          </div>
        </div>
      </div>
    </section>);

}

/* =================== Heatmap view =================== */
function HeatmapView({ stations, accent, range }) {
  const days = range === "24h" ? 1 : range === "7d" ? 7 : 30;
  return (
    <section className="card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 14 }}>
        <div>
          <h2 style={{ margin: "0 0 4px", fontSize: 18 }}>Hour-of-day intensity</h2>
          <div style={{ fontSize: 12.5, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
            Average mm/h by hour, last {days} day{days > 1 ? "s" : ""}
          </div>
        </div>
        <div className="hm-legend">
          <span>0</span>
          <div className="gradient" />
          <span>peak</span>
        </div>
      </div>
      <div className="heatmap-wrap">
        <div className="heatmap">
          <div className="hm-label" />
          {Array.from({ length: 24 }).map((_, h) =>
          <div key={h} className="hm-axis">{h.toString().padStart(2, "0")}</div>
          )}
          {stations.map((s) =>
          <HeatmapRow key={s.id} station={s} days={days} accent={accent} />
          )}
        </div>
      </div>
    </section>);

}

/* =================== Alerts view =================== */
function AlertsView({ stations, accent, showAI }) {
  const [threshold, setThreshold] = useState(25);
  const [aiText, setAiText] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);

  const alerts = useMemo(() => {
    const items = [];
    stations.forEach((station) => {
      const s24 = station.series.slice(-24);
      const total24 = s24.reduce((a, b) => a + b.value, 0);
      const peak = s24.reduce((m, p) => p.value > m.value ? p : m, s24[0]);
      if (total24 >= threshold) {
        items.push({
          id: `${station.id}-tot`,
          sev: total24 >= threshold * 2 ? "high" : "med",
          title: `${station.name} exceeded ${threshold} mm in 24h`,
          desc: `${total24.toFixed(1)} mm accumulated. Peak intensity ${peak.value.toFixed(1)} mm/h at ${fmtDayHour(peak.timestamp)}.`,
          time: peak.timestamp,
          icon: Icon.warn
        });
      }
      if (peak.value >= 8) {
        items.push({
          id: `${station.id}-peak`,
          sev: peak.value >= 15 ? "high" : "med",
          title: `High intensity at ${station.name}`,
          desc: `Hourly intensity reached ${peak.value.toFixed(1)} mm/h — review for surface runoff risk.`,
          time: peak.timestamp,
          icon: Icon.spark
        });
      }
    });
    // calm note if none
    if (items.length === 0) {
      items.push({
        id: "calm",
        sev: "low",
        title: "No active warnings",
        desc: "All four stations report sub-threshold rainfall over the last 24 hours.",
        time: new Date().toISOString(),
        icon: Icon.drop
      });
    }
    return items.sort((a, b) => new Date(b.time) - new Date(a.time));
  }, [stations, threshold]);

  async function generateSummary() {
    if (!window.claude) return;
    setAiLoading(true);
    try {
      const facts = stations.map((s) => {
        const last24 = s.series.slice(-24);
        return {
          name: s.name,
          site: s.site,
          total_24h_mm: +last24.reduce((a, b) => a + b.value, 0).toFixed(1),
          peak_mm_per_h: +Math.max(...last24.map((p) => p.value)).toFixed(1),
          wet_hours: last24.filter((p) => p.value >= 0.2).length
        };
      });
      const prompt = `You are a hydrology analyst writing a 1-paragraph (~60 words) plain-English briefing for an Auckland Council conservation team. Summarise the past 24 hours of rainfall from these four stations. Mention which area is wettest and any operational concerns. Do not use bullet points or headers. Be concise and factual.\n\nData (JSON):\n${JSON.stringify(facts)}`;
      const text = await window.claude.complete(prompt);
      setAiText(text.trim());
    } catch (e) {
      setAiText("Summary unavailable — check connection.");
    } finally {
      setAiLoading(false);
    }
  }

  useEffect(() => {
    if (showAI && !aiText) generateSummary();
    // eslint-disable-next-line
  }, [showAI]);

  return (
    <section style={{ display: "flex", flexDirection: "column", gap: "var(--gap)" }}>
      {showAI &&
      <div className="ai-summary">
          <div className="icon"><Icon.spark /></div>
          <div className="body">
            <div className="label">Conservation briefing · AI</div>
            <div className="text">
              {aiLoading ? "Generating briefing…" : aiText || "Click 'Generate' to produce a 24-hour summary."}
            </div>
            {!aiLoading &&
          <button className="filter-pill" style={{ alignSelf: "flex-start", marginTop: 4 }}
          onClick={generateSummary}>
                Regenerate
              </button>
          }
          </div>
        </div>
      }

      <div className="card">
        <div className="threshold-row">
          <span className="control-label">24h alert threshold</span>
          <input type="number" min="1" max="200" step="1"
          value={threshold} onChange={(e) => setThreshold(+e.target.value || 0)} />
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>mm</span>
          <span style={{ color: "var(--text-soft)", fontSize: 12 }}>· MetService heavy-rain warning starts at 50 mm/24h</span>
        </div>
      </div>

      {alerts.map((a) => {
        const I = a.icon;
        return (
          <div key={a.id} className={`alert-card sev-${a.sev}`}>
            <div className="alert-icon"><I /></div>
            <div className="alert-body">
              <div className="alert-title">{a.title}</div>
              <div className="alert-meta">{fmtDayHour(a.time)} · severity {a.sev}</div>
              <div className="alert-desc">{a.desc}</div>
            </div>
          </div>);

      })}
    </section>);

}

/* =================== App =================== */
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = useState("dashboard");
  const [openedId, setOpenedId] = useState(null);
  const [range, setRange] = useState("24h");
  const [unit, setUnit] = useState("rate");
  const [seed, setSeed] = useState(42);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [filter, setFilter] = useState(["central", "waitakere", "takapuna", "manukau"]);

  // resolve accent based on theme. accent is stored as the light-mode hex.
  const accentHex = useMemo(() => {
    const preset = ACCENT_PRESETS.find((p) => p.light === t.accent) || ACCENT_PRESETS[0];
    return t.theme === "dark" ? preset.dark : preset.light;
  }, [t.accent, t.theme]);

  useEffect(() => {
    document.documentElement.dataset.theme = t.theme;
    document.documentElement.dataset.density = t.density;
    document.documentElement.style.setProperty("--accent", accentHex);
    document.documentElement.style.setProperty("--accent-soft", accentHex + "1f");
  }, [t.theme, t.density, accentHex]);

  const stations = useMemo(() => RainfallData.buildAll(seed), [seed]);

  function handleRefresh() {
    setRefreshing(true);
    setTimeout(() => {
      setSeed((s) => s + 1);
      setLastUpdated(new Date());
      setRefreshing(false);
    }, 900);
  }

  function toggleFilter(id) {
    setFilter((f) => f.includes(id) ? f.filter((x) => x !== id) : [...f, id]);
  }

  const openedStation = useMemo(
    () => stations.find((s) => s.id === openedId),
    [openedId, stations]
  );

  ControlsBar._tab = view;
  ControlsBar._onTab = (v) => {setView(v);setOpenedId(null);};

  return (
    <div className="app">
      <Header
        lastUpdated={lastUpdated}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        theme={t.theme}
        onThemeToggle={() => setTweak("theme", t.theme === "dark" ? "light" : "dark")} />
      

      {!openedStation &&
      <ControlsBar
        range={range}
        onRange={setRange}
        unit={unit}
        onUnit={setUnit}
        stations={stations}
        filter={filter}
        onFilter={toggleFilter}
        showLocations={view === "dashboard"}
        hideRangeControls={view === "map"} />

      }

      {openedStation ?
      <DrillView
        station={openedStation}
        range={range}
        unit={unit}
        accent={accentHex}
        onBack={() => setOpenedId(null)} /> :

      view === "dashboard" ?
      <DashboardView
        stations={stations}
        range={range}
        unit={unit}
        accent={accentHex}
        chartType={t.chartType}
        filter={filter}
        onOpen={(id) => setOpenedId(id)} /> :

      view === "map" ?
      <MapView
        stations={stations}
        accent={accentHex}
        onOpen={(id) => setOpenedId(id)} /> :

      view === "heatmap" ?
      <HeatmapView stations={stations} accent={accentHex} range={range} /> :

      <AlertsView stations={stations} accent={accentHex} showAI={t.showAI} />
      }

      <TweaksPanel title="Tweaks" defaultOpen={false}>
        <TweakSection label="Theme" />
        <TweakRadio
          label="Mode"
          value={t.theme}
          onChange={(v) => setTweak("theme", v)}
          options={[
          { value: "light", label: "Light" },
          { value: "dark", label: "Dark" }]
          } />
        
        <TweakColor
          label="Accent"
          value={t.accent}
          onChange={(v) => setTweak("accent", v)}
          options={ACCENT_PRESETS.map((p) => p.light)} />
        
        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          onChange={(v) => setTweak("density", v)}
          options={[
          { value: "comfy", label: "Comfy" },
          { value: "compact", label: "Compact" }]
          } />
        
        <TweakSection label="Alerts" />
        <TweakToggle
          label="AI briefing"
          value={!!t.showAI}
          onChange={(v) => setTweak("showAI", v)} />
        
      </TweaksPanel>
    </div>);

}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);