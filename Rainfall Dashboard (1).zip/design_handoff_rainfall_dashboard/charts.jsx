/* global React */
// SVG charts: BarChart (24h hourly), LineChart, Heatmap row.
// Designed to be crisp, responsive and tooltip-aware.

const { useState, useMemo, useRef, useEffect } = React;

function fmtTime(iso, opts = {}) {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", ...opts });
}
function fmtDayHour(iso) {
  const d = new Date(iso);
  const day = d.toLocaleDateString([], { weekday: "short", day: "2-digit", month: "short" });
  const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  return `${day} · ${time}`;
}
function fmtMM(n) {
  if (n === 0) return "0";
  if (n < 0.1) return n.toFixed(2);
  if (n < 10) return n.toFixed(1);
  return n.toFixed(0);
}

/* ===================== BarChart ===================== */
function BarChart({ series, height = 110, accent, mode = "hourly", compact = false }) {
  const [hover, setHover] = useState(null);
  const wrapRef = useRef(null);
  const W = 320;
  const H = height;
  const padX = 4;
  const padY = compact ? 8 : 12;
  const bottomAxis = compact ? 14 : 18;

  const data = useMemo(() => {
    if (mode === "cumulative") {
      let acc = 0;
      return series.map((p) => ({ ...p, value: (acc += p.value) }));
    }
    return series;
  }, [series, mode]);

  const max = useMemo(() => {
    const m = Math.max(0.5, ...data.map((d) => d.value));
    // round up to nicer max
    if (m < 1) return 1;
    if (m < 2) return 2;
    if (m < 5) return Math.ceil(m);
    if (m < 10) return Math.ceil(m / 2) * 2;
    if (m < 50) return Math.ceil(m / 5) * 5;
    return Math.ceil(m / 10) * 10;
  }, [data]);

  const n = data.length;
  const innerW = W - padX * 2;
  const innerH = H - padY - bottomAxis;
  const barW = Math.max(1, innerW / n - 1.5);
  const step = innerW / n;

  // gridlines
  const gridY = [0, 0.5, 1].map((f) => padY + innerH * (1 - f));

  // x ticks: adapt label format + density to span so they never crowd or overlap.
  const xTicks = useMemo(() => {
    if (n === 0) return [];
    const first = new Date(data[0].timestamp);
    const last = new Date(data[n - 1].timestamp);
    const spanHours = (last - first) / 36e5;
    // Compact card width is ~320 svg-units; cap labels so they don't collide.
    const maxLabels = compact ? 4 : 5;
    const fmtHour = (d) => d.getHours().toString().padStart(2, "0") + ":00";
    const fmtDay = (d) => d.toLocaleDateString([], { weekday: "short" });
    const fmtDate = (d) => d.toLocaleDateString([], { day: "numeric", month: "short" });

    let candidates = [];
    if (spanHours <= 36) {
      // hourly labels every 6h aligned to clock
      for (let i = 0; i < n; i++) {
        const d = new Date(data[i].timestamp);
        if (d.getHours() % 6 === 0 && d.getMinutes() === 0) {
          candidates.push({ i, label: fmtHour(d) });
        }
      }
    } else if (spanHours <= 24 * 10) {
      // weekday labels at start of each day
      for (let i = 0; i < n; i++) {
        const d = new Date(data[i].timestamp);
        if (d.getHours() === 0) candidates.push({ i, label: fmtDay(d) });
      }
    } else {
      // date labels at start of each day
      for (let i = 0; i < n; i++) {
        const d = new Date(data[i].timestamp);
        if (d.getHours() === 0) candidates.push({ i, label: fmtDate(d) });
      }
    }
    // thin evenly to maxLabels so labels never overlap
    if (candidates.length > maxLabels) {
      const stride = Math.ceil(candidates.length / maxLabels);
      candidates = candidates.filter((_, k) => k % stride === 0);
    }
    return candidates;
  }, [data, n, compact]);

  function onMove(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * W;
    const i = Math.max(0, Math.min(n - 1, Math.floor((x - padX) / step)));
    setHover({ i, x: ((padX + (i + 0.5) * step) / W) * 100, ...data[i] });
  }

  return (
    <div className="chart-wrap" ref={wrapRef}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        preserveAspectRatio="none"
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
        onTouchStart={(e) => onMove(e.touches[0])}
        onTouchMove={(e) => onMove(e.touches[0])}
        onTouchEnd={() => setHover(null)}
      >
        {/* gridlines */}
        {gridY.map((y, i) => (
          <line key={i} x1={padX} x2={W - padX} y1={y} y2={y}
            stroke="var(--border)" strokeWidth="1"
            strokeDasharray={i === gridY.length - 1 ? "0" : "2 3"} />
        ))}
        {/* y-axis label (top) */}
        <text x={padX + 2} y={padY - 2} fontSize="9" fill="var(--text-soft)"
          fontFamily="var(--font-mono)">{max} mm</text>

        {/* bars */}
        {data.map((d, i) => {
          const v = Math.max(0, d.value);
          const h = (v / max) * innerH;
          const x = padX + i * step + (step - barW) / 2;
          const y = padY + innerH - h;
          const isHover = hover && hover.i === i;
          return (
            <rect
              key={i}
              x={x}
              y={y}
              width={barW}
              height={Math.max(h, v > 0 ? 1 : 0)}
              rx={Math.min(1.5, barW / 2)}
              fill={accent || "var(--accent)"}
              opacity={hover ? (isHover ? 1 : 0.55) : v === 0 ? 0.08 : 0.95}
              style={{ transition: "opacity 120ms" }}
            />
          );
        })}

        {/* x ticks */}
        {xTicks.map((t) => (
          <text
            key={t.i}
            x={padX + (t.i + 0.5) * step}
            y={H - 4}
            fontSize="9"
            fill="var(--text-soft)"
            fontFamily="var(--font-mono)"
            textAnchor="middle"
          >
            {t.label}
          </text>
        ))}

        {/* hover indicator */}
        {hover && (
          <line
            x1={padX + (hover.i + 0.5) * step}
            x2={padX + (hover.i + 0.5) * step}
            y1={padY}
            y2={padY + innerH}
            stroke="var(--text)"
            strokeOpacity="0.25"
            strokeWidth="1"
          />
        )}
      </svg>
      {hover && (
        <div className="chart-tooltip" style={{ left: `${hover.x}%`, top: 0 }}>
          <div><b>{fmtMM(hover.value)} mm</b>{mode === "cumulative" ? " total" : "/h"}</div>
          <div className="chart-tooltip-time">{fmtDayHour(hover.timestamp)}</div>
        </div>
      )}
    </div>
  );
}

/* ===================== LineChart (for drill-in) ===================== */
function LineChart({ series, height = 280, accent, mode = "hourly" }) {
  const [hover, setHover] = useState(null);
  const W = 800;
  const H = height;
  const padL = 36;
  const padR = 14;
  const padT = 16;
  const padB = 28;

  const data = useMemo(() => {
    if (mode === "cumulative") {
      let acc = 0;
      return series.map((p) => ({ ...p, value: (acc += p.value) }));
    }
    return series;
  }, [series, mode]);

  const max = useMemo(() => {
    const m = Math.max(0.5, ...data.map((d) => d.value));
    if (m < 1) return 1;
    if (m < 5) return Math.ceil(m);
    if (m < 50) return Math.ceil(m / 5) * 5;
    return Math.ceil(m / 10) * 10;
  }, [data]);

  const n = data.length;
  const innerW = W - padL - padR;
  const innerH = H - padT - padB;
  const step = innerW / Math.max(1, n - 1);

  const points = data.map((d, i) => [padL + i * step, padT + innerH - (d.value / max) * innerH]);
  const path = points.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(" ");
  const area = `${path} L${points[points.length - 1][0]},${padT + innerH} L${padL},${padT + innerH} Z`;

  // y ticks: 0, 25, 50, 75, 100% of max
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((f) => ({
    y: padT + innerH * (1 - f),
    label: f === 0 ? "0" : fmtMM(max * f),
  }));

  // x ticks: roughly 6-8
  const tickCount = Math.min(8, Math.max(4, Math.floor(n / 8)));
  const xTicks = [];
  for (let k = 0; k < tickCount; k++) {
    const i = Math.round((k / (tickCount - 1)) * (n - 1));
    if (data[i]) xTicks.push({ i, label: fmtTime(data[i].timestamp), date: data[i].timestamp });
  }

  function onMove(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * W;
    const i = Math.max(0, Math.min(n - 1, Math.round((x - padL) / step)));
    setHover({ i, ...data[i], px: padL + i * step, py: padT + innerH - (data[i].value / max) * innerH });
  }

  return (
    <div className="chart-wrap">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        preserveAspectRatio="none"
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
      >
        {yTicks.map((t, i) => (
          <g key={i}>
            <line x1={padL} x2={W - padR} y1={t.y} y2={t.y}
              stroke="var(--border)" strokeWidth="1"
              strokeDasharray={i === 0 ? "0" : "2 3"} />
            <text x={padL - 6} y={t.y + 3} fontSize="10"
              fill="var(--text-soft)" fontFamily="var(--font-mono)" textAnchor="end">
              {t.label}
            </text>
          </g>
        ))}

        {/* area */}
        <path d={area} fill={accent || "var(--accent)"} opacity="0.1" />
        {/* line */}
        <path d={path} fill="none" stroke={accent || "var(--accent)"} strokeWidth="1.8"
          strokeLinejoin="round" strokeLinecap="round" />

        {/* x labels */}
        {xTicks.map((t, i) => (
          <text
            key={i}
            x={padL + t.i * step}
            y={H - 8}
            fontSize="10"
            fill="var(--text-soft)"
            fontFamily="var(--font-mono)"
            textAnchor="middle"
          >
            {t.label}
          </text>
        ))}

        {/* hover */}
        {hover && (
          <>
            <line x1={hover.px} x2={hover.px} y1={padT} y2={padT + innerH}
              stroke="var(--text)" strokeOpacity="0.25" strokeWidth="1" />
            <circle cx={hover.px} cy={hover.py} r="4"
              fill="var(--surface)" stroke={accent || "var(--accent)"} strokeWidth="2" />
          </>
        )}
      </svg>
      {hover && (
        <div className="chart-tooltip" style={{
          left: `${(hover.px / W) * 100}%`,
          top: `${(hover.py / H) * 100}%`,
        }}>
          <div><b>{fmtMM(hover.value)} mm</b>{mode === "cumulative" ? " total" : "/h"}</div>
          <div className="chart-tooltip-time">{fmtDayHour(hover.timestamp)}</div>
        </div>
      )}
    </div>
  );
}

/* ===================== Heatmap row ===================== */
function HeatmapRow({ station, days, accent }) {
  // group last (days*24) hours by day-of-cell (0-23 hours) for the last N days
  const series = station.series.slice(-days * 24);
  const matrix = [];
  for (let d = 0; d < days; d++) {
    matrix.push(series.slice(d * 24, (d + 1) * 24));
  }
  const max = Math.max(0.5, ...series.map((p) => p.value));

  return (
    <>
      <div className="hm-label">{station.name}</div>
      {Array.from({ length: 24 }).map((_, hour) => {
        // average across days for that hour-of-day across the window
        let sum = 0;
        let count = 0;
        matrix.forEach((row) => {
          if (row[hour]) {
            sum += row[hour].value;
            count++;
          }
        });
        const v = count ? sum / count : 0;
        const intensity = Math.min(1, v / max);
        const bg =
          intensity < 0.02
            ? "var(--surface-2)"
            : `color-mix(in oklab, ${accent || "var(--accent)"} ${Math.round(20 + intensity * 80)}%, var(--surface-2))`;
        return (
          <div
            key={hour}
            className="hm-cell"
            style={{ background: bg }}
            title={`${hour.toString().padStart(2, "0")}:00 — ${fmtMM(v)} mm/h avg`}
          />
        );
      })}
    </>
  );
}

/* ===================== Aggregated Block BarChart =====================
   For arbitrary time-block aggregations (e.g. 6h blocks, daily totals).
   `bars` = [{value, label, sub}], where label is the on-axis text
   shown at a subset of indices (driven by `tickEvery`). */

function aggregateBlocks(series, hoursPerBlock, options = {}) {
  // series is hourly; produce N blocks of `hoursPerBlock` hours each,
  // covering the most recent (count * hoursPerBlock) hours.
  const { count, labelFor } = options;
  const total = count ? count * hoursPerBlock : series.length;
  const slice = series.slice(-total);
  const out = [];
  for (let i = 0; i < slice.length; i += hoursPerBlock) {
    const block = slice.slice(i, i + hoursPerBlock);
    if (!block.length) break;
    const sum = block.reduce((a, b) => a + b.value, 0);
    const peak = Math.max(...block.map((p) => p.value));
    const start = block[0].timestamp;
    const end = block[block.length - 1].timestamp;
    const bar = {
      value: sum,
      peak,
      start,
      end,
      timestamp: start,
    };
    if (labelFor) Object.assign(bar, labelFor(bar, out.length));
    out.push(bar);
  }
  return out;
}

function BlockBarChart({ bars, accent, height = 140, tickEvery = 4, axisFormat, tooltipFormat }) {
  const [hover, setHover] = useState(null);
  const W = 640;
  const H = height;
  const padX = 6;
  const padT = 14;
  const padB = 24;

  const max = useMemo(() => {
    const m = Math.max(0.5, ...bars.map((b) => b.value));
    if (m < 1) return 1;
    if (m < 5) return Math.ceil(m);
    if (m < 50) return Math.ceil(m / 5) * 5;
    return Math.ceil(m / 10) * 10;
  }, [bars]);

  const n = bars.length;
  const innerW = W - padX * 2;
  const innerH = H - padT - padB;
  const step = innerW / n;
  const barW = Math.max(2, step - 2);

  function onMove(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * W;
    const i = Math.max(0, Math.min(n - 1, Math.floor((x - padX) / step)));
    setHover({ i, x: ((padX + (i + 0.5) * step) / W) * 100, ...bars[i] });
  }

  const gridY = [0, 0.5, 1].map((f) => padT + innerH * (1 - f));

  return (
    <div className="chart-wrap">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        preserveAspectRatio="none"
        onMouseMove={onMove}
        onMouseLeave={() => setHover(null)}
        onTouchStart={(e) => onMove(e.touches[0])}
        onTouchMove={(e) => onMove(e.touches[0])}
        onTouchEnd={() => setHover(null)}
      >
        {gridY.map((y, i) => (
          <line key={i} x1={padX} x2={W - padX} y1={y} y2={y}
            stroke="var(--border)" strokeWidth="1"
            strokeDasharray={i === gridY.length - 1 ? "0" : "2 3"} />
        ))}
        <text x={padX + 2} y={padT - 2} fontSize="9" fill="var(--text-soft)"
          fontFamily="var(--font-mono)">{max} mm</text>

        {bars.map((b, i) => {
          const v = Math.max(0, b.value);
          const h = (v / max) * innerH;
          const x = padX + i * step + (step - barW) / 2;
          const y = padT + innerH - h;
          const isHover = hover && hover.i === i;
          return (
            <rect
              key={i}
              x={x}
              y={y}
              width={barW}
              height={Math.max(h, v > 0 ? 1 : 0)}
              rx={Math.min(1.5, barW / 2)}
              fill={accent || "var(--accent)"}
              opacity={hover ? (isHover ? 1 : 0.55) : v === 0 ? 0.08 : 0.95}
              style={{ transition: "opacity 120ms" }}
            />
          );
        })}

        {/* x-axis labels — every `tickEvery` bar */}
        {bars.map((b, i) => {
          if (i % tickEvery !== 0) return null;
          const label = axisFormat ? axisFormat(b, i) : b.label || "";
          if (!label) return null;
          return (
            <text
              key={i}
              x={padX + (i + 0.5) * step}
              y={H - 6}
              fontSize="9"
              fill="var(--text-soft)"
              fontFamily="var(--font-mono)"
              textAnchor="middle"
            >
              {label}
            </text>
          );
        })}

        {hover && (
          <line
            x1={padX + (hover.i + 0.5) * step}
            x2={padX + (hover.i + 0.5) * step}
            y1={padT}
            y2={padT + innerH}
            stroke="var(--text)"
            strokeOpacity="0.25"
            strokeWidth="1"
          />
        )}
      </svg>
      {hover && (
        <div className="chart-tooltip" style={{ left: `${hover.x}%`, top: 0 }}>
          {tooltipFormat
            ? tooltipFormat(hover)
            : <div><b>{fmtMM(hover.value)} mm</b></div>}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { BarChart, LineChart, HeatmapRow, BlockBarChart, aggregateBlocks, fmtTime, fmtDayHour, fmtMM });
