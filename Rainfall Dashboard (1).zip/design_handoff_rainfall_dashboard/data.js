// Realistic mock rainfall data shaped like the Auckland Council hydrotel KiWIS API.
// Each station has 30 days * 24h of hourly rainfall (mm) ending at "now".
// Stations carry their real metadata + ts_id from the user-provided endpoints.

(function () {
  const STATIONS = [
    {
      id: "central",
      name: "Auckland Central",
      site: "Albert Park",
      ts_id: "648719",
      lat: -36.8523,
      lng: 174.7691,
      elevation: 75,
      // wetter, urban
      wetFactor: 1.0,
      stormHour: 6,
    },
    {
      id: "waitakere",
      name: "Waitakere",
      site: "Keeling Road",
      ts_id: "647722",
      lat: -36.9075,
      lng: 174.5847,
      elevation: 210,
      // wettest, ranges
      wetFactor: 1.55,
      stormHour: 4,
    },
    {
      id: "takapuna",
      name: "Takapuna",
      site: "Wairau Testing Station",
      ts_id: "648612",
      lat: -36.7833,
      lng: 174.7644,
      elevation: 18,
      // coastal, lighter
      wetFactor: 0.78,
      stormHour: 9,
    },
    {
      id: "manukau",
      name: "Manukau",
      site: "Manukau Sports Bowl",
      ts_id: "649940",
      lat: -36.9939,
      lng: 174.8797,
      elevation: 32,
      // south, moderate
      wetFactor: 0.92,
      stormHour: 11,
    },
  ];

  // Deterministic PRNG so the dashboard looks the same across refreshes
  // unless the "refresh" button bumps the seed.
  function mulberry32(seed) {
    return function () {
      let t = (seed += 0x6d2b79f5);
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function generateSeries(station, hours, refSeed) {
    const rng = mulberry32(refSeed + station.id.charCodeAt(0) * 991);
    const data = [];
    const now = new Date();
    // round down to top of hour
    now.setMinutes(0, 0, 0);

    // place 1-3 storm cells across the window
    const stormCount = 1 + Math.floor(rng() * 3);
    const stormCenters = [];
    for (let i = 0; i < stormCount; i++) {
      stormCenters.push({
        center: Math.floor(rng() * hours),
        width: 3 + Math.floor(rng() * 6),
        peak: (1.5 + rng() * 6) * station.wetFactor,
      });
    }
    // emphasize a recent storm at stormHour to make 24h view interesting
    stormCenters.push({
      center: hours - station.stormHour,
      width: 4 + Math.floor(rng() * 4),
      peak: (2 + rng() * 5) * station.wetFactor,
    });

    for (let i = 0; i < hours; i++) {
      const t = new Date(now.getTime() - (hours - 1 - i) * 3600 * 1000);
      // diurnal: slightly wetter in early morning hours
      const hourOfDay = t.getHours();
      const diurnal = 0.15 + 0.1 * Math.cos(((hourOfDay - 5) / 24) * Math.PI * 2);
      // baseline drizzle
      let v = Math.max(0, (rng() - 0.78) * 0.6) * station.wetFactor * diurnal;
      // storm cells
      for (const s of stormCenters) {
        const d = (i - s.center) / s.width;
        const g = Math.exp(-d * d) * s.peak;
        v += g * (0.6 + rng() * 0.5);
      }
      // noise
      v += rng() * 0.05;
      if (v < 0.02) v = 0;
      data.push({
        timestamp: t.toISOString(),
        value: Math.round(v * 100) / 100,
        quality: rng() > 0.985 ? 200 : 1, // occasional flagged value
      });
    }
    return data;
  }

  function buildAll(refSeed = 42) {
    const hours = 30 * 24; // 30 days
    return STATIONS.map((s) => ({
      ...s,
      series: generateSeries(s, hours, refSeed),
    }));
  }

  window.RainfallData = {
    STATIONS,
    buildAll,
  };
})();
