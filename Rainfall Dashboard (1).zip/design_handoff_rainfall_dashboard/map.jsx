/* global React, fmtMM, RegionShapes */
// MapView — four real region silhouettes (provided as SVG) tinted by 24h rainfall.
// Arranged geographically and clickable to drill in.

const { useState: __useStateMap, useMemo: __useMemoMap } = React;

// Geographic relationships in Auckland:
// - Takapuna sits north (across Waitemata Harbour)
// - Waitakere is west (Ranges)
// - Central (Albert Park area, isthmus + waterfront) center
// - Manukau is south
// We render each tile as a region silhouette card.

const __regionDisplay = {
  takapuna:  { label: "Takapuna",        cardinal: "North Shore"     },
  waitakere: { label: "Waitakere",       cardinal: "Western Ranges"  },
  central:   { label: "Auckland Central",cardinal: "Isthmus"         },
  manukau:   { label: "Manukau",         cardinal: "South Auckland"  },
};

function RegionTile({ station, total, peak, intensity, accent, onClick, hovered, onHoverChange }) {
  const shape = RegionShapes.regions[station.id];
  if (!shape) return null;
  // Tint: accent at high intensity, neutral at low
  const fill =
    intensity < 0.02
      ? `color-mix(in oklab, ${accent} 8%, var(--surface-2))`
      : `color-mix(in oklab, ${accent} ${Math.round(25 + intensity * 70)}%, var(--surface-2))`;
  const stroke = `color-mix(in oklab, ${accent} ${Math.round(45 + intensity * 50)}%, var(--text-soft))`;
  const display = __regionDisplay[station.id];

  return (
    <button
      className={`region-tile${hovered ? " is-hovered" : ""}`}
      onClick={onClick}
      onMouseEnter={() => onHoverChange(true)}
      onMouseLeave={() => onHoverChange(false)}
      aria-label={`${station.name}, ${total.toFixed(1)} mm in 24 hours`}
    >
      <div className="region-tile-shape">
        <svg viewBox={shape.viewBox} preserveAspectRatio="xMidYMid meet"
             role="img" aria-hidden="true">
          <path d={shape.d}
                fill={fill}
                stroke={stroke}
                strokeWidth={Math.max(0.8, shape.w / 500)}
                fillRule="evenodd"
                style={{ transition: "fill 200ms" }} />
        </svg>
      </div>
      <div className="region-tile-meta">
        <div className="region-tile-name">
          <strong>{display.label}</strong>
          <span>{display.cardinal} · {station.site}</span>
        </div>
        <div className="region-tile-num">
          <strong>{fmtMM(total)}<i>mm</i></strong>
          <span>peak {fmtMM(peak)} mm/h</span>
        </div>
      </div>
    </button>
  );
}

function MapView({ stations, accent, onOpen }) {
  const [hoverId, setHover] = __useStateMap(null);

  const data = __useMemoMap(() => {
    const totals = {};
    let max = 0;
    stations.forEach((s) => {
      const last24 = s.series.slice(-24);
      const total = last24.reduce((a, b) => a + b.value, 0);
      const peak = Math.max(...last24.map((p) => p.value));
      totals[s.id] = { total, peak, station: s };
      if (total > max) max = total;
    });
    return { totals, max: Math.max(2, max) };
  }, [stations]);

  // Roughly geographic 2x2 layout:
  // [ Waitakere    | Takapuna    ]
  // [ Central      | Manukau     ]
  const orderedIds = ["waitakere", "takapuna", "central", "manukau"];
  const ordered = orderedIds
    .map((id) => stations.find((s) => s.id === id))
    .filter(Boolean);

  // Total rainfall across all four for the strip
  const allTotal = Object.values(data.totals).reduce((a, b) => a + b.total, 0);

  return (
    <section className="card map-card">
      <div className="map-head">
        <div>
          <h2 style={{ margin: "0 0 4px", fontSize: 18, letterSpacing: "-0.01em" }}>
            24-hour rainfall by region
          </h2>
          <div style={{ fontSize: 12.5, color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
            Region tinted by total mm · tap to drill in
          </div>
        </div>
        <div className="map-head-right">
          <div className="map-total">
            <span className="control-label">All regions</span>
            <strong>{fmtMM(allTotal)}<i> mm</i></strong>
          </div>
          <div className="hm-legend" aria-label="Rainfall scale">
            <span>0</span>
            <div className="gradient" />
            <span>{fmtMM(data.max)}</span>
          </div>
        </div>
      </div>

      <div className="region-grid" data-region-layout>
        {ordered.map((s) => {
          const d = data.totals[s.id];
          const intensity = Math.min(1, d.total / data.max);
          return (
            <RegionTile
              key={s.id}
              station={s}
              total={d.total}
              peak={d.peak}
              intensity={intensity}
              accent={accent}
              hovered={hoverId === s.id}
              onHoverChange={(v) => setHover(v ? s.id : null)}
              onClick={() => onOpen(s.id)}
            />
          );
        })}
      </div>
    </section>
  );
}

Object.assign(window, { MapView });
